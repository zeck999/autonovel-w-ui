"""
Autonovel src package.
"""
